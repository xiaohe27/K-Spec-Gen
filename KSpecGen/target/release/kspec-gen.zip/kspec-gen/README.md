# K-Spec-Gen
Generate k-spec from annotated java file which can be used as the input of k verifier
