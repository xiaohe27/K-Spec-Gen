public class min {

    /**
     * @requires x > 7 && y <= x * 4 -9/8;
     * @returns minInt(x, y);
     */
    static int min(int x, int y) {
        if (x <= y)
            return x;
        else
            return x;
    }

    /**
     * @requires a < b;
     */
    static boolean isLT(int a, int b) {

    }
}
